package prog21oop.testejava;

public class pessoa {
    public String nome;

    public pessoa(String nome) {
        this.nome = nome;
    }
}
