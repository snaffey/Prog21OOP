package prog21oop.DesafioEntrega08112022;

public class SeçãoInteresse {
    public Long id;
    public String nome;
    public Long qtd_anucios;

    public SeçãoInteresse(Long id, String nome, Long qtd_anucios) {
        this.id = id;
        this.nome = nome;
        this.qtd_anucios = qtd_anucios;
    }

    
}
