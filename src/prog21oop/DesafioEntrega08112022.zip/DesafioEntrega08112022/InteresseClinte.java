package prog21oop.DesafioEntrega08112022;

public class InteresseClinte {
    
}
