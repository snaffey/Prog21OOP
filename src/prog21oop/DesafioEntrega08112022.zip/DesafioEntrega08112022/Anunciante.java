package prog21oop.DesafioEntrega08112022;

public class Anunciante extends ClienteRegistado{
    public Anunciante(Long id, String login, String password) {
        super(id, login, password);
    }
}
