package prog21oop.DesafioEntrega08112022;

public class Anuncio {
    public Long id;
    public String palavras;

}
